from __future__ import annotations

import base64
import stat
from pathlib import Path
from types import SimpleNamespace

import pytest

from tikvaron_image_generation import (
    ImageGenerationClient,
    ImageGenerationError,
    ImageGenerationModerationError,
)

PNG_BYTES = b"\x89PNG\r\n\x1a\nTIKVARON-TEST"
PNG_B64 = base64.b64encode(PNG_BYTES).decode("ascii")


class FakeImages:
    def __init__(self):
        self.generate_kwargs = None
        self.edit_kwargs = None
        self.generate_data = [SimpleNamespace(b64_json=PNG_B64, revised_prompt="revised")]
        self.edit_data = [SimpleNamespace(b64_json=PNG_B64, revised_prompt="edited")]
        self.error = None
        self.stream_events = []

    def generate(self, **kwargs):
        self.generate_kwargs = kwargs
        if self.error:
            raise self.error
        if kwargs.get("stream"):
            return iter(self.stream_events)
        return SimpleNamespace(data=self.generate_data)

    def edit(self, **kwargs):
        self.edit_kwargs = kwargs
        if self.error:
            raise self.error
        return SimpleNamespace(data=self.edit_data)


class FakeResponses:
    def __init__(self):
        self.kwargs = None
        self.error = None
        self.response = SimpleNamespace(
            id="resp_image_001",
            output=[
                SimpleNamespace(
                    type="image_generation_call",
                    status="completed",
                    result=PNG_B64,
                    revised_prompt="a refined prompt",
                )
            ],
            output_text="",
        )
        self.events = []

    def create(self, **kwargs):
        self.kwargs = kwargs
        if self.error:
            raise self.error
        if kwargs.get("stream"):
            return iter(self.events)
        return self.response


class FakeFiles:
    def __init__(self):
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        return SimpleNamespace(id="file_vision_001")


class FakeSDK:
    def __init__(self):
        self.images = FakeImages()
        self.responses = FakeResponses()
        self.files = FakeFiles()


def test_rejects_blank_prompt_before_calling_openai(tmp_path: Path):
    sdk = FakeSDK()
    generator = ImageGenerationClient(client=sdk)

    with pytest.raises(ValueError, match="prompt must not be empty"):
        generator.generate("  \n", tmp_path / "image.png")

    assert sdk.images.generate_kwargs is None


def test_generate_saves_image_bytes_with_private_permissions(tmp_path: Path):
    sdk = FakeSDK()
    generator = ImageGenerationClient(client=sdk)
    destination = tmp_path / "artwork.png"

    result = generator.generate("A bright sunrise over Nairobi", destination)

    assert result.paths == (destination,)
    assert destination.read_bytes() == PNG_BYTES
    assert stat.S_IMODE(destination.stat().st_mode) == 0o600
    assert sdk.images.generate_kwargs["model"] == "gpt-image-2.5-sunburst"
    assert sdk.images.generate_kwargs["prompt"] == "A bright sunrise over Nairobi"


def test_generate_numbers_multiple_image_outputs(tmp_path: Path):
    sdk = FakeSDK()
    sdk.images.generate_data = [
        SimpleNamespace(b64_json=PNG_B64),
        SimpleNamespace(b64_json=PNG_B64),
    ]
    result = ImageGenerationClient(client=sdk).generate(
        "Two design directions", tmp_path / "direction.png", n=2
    )

    assert [path.name for path in result.paths] == ["direction.png", "direction-2.png"]
    assert all(path.read_bytes() == PNG_BYTES for path in result.paths)


def test_edit_passes_reference_and_mask_file_handles_and_closes_them(tmp_path: Path):
    sdk = FakeSDK()
    generator = ImageGenerationClient(client=sdk)
    reference = tmp_path / "reference.png"
    mask = tmp_path / "mask.png"
    reference.write_bytes(PNG_BYTES)
    mask.write_bytes(PNG_BYTES)

    result = generator.edit(
        "Change the vase to cobalt blue", reference, tmp_path / "edited.png", mask=mask
    )

    assert result.paths == (tmp_path / "edited.png",)
    assert result.paths[0].read_bytes() == PNG_BYTES
    assert sdk.images.edit_kwargs["model"] == "gpt-image-2.5-sunburst"
    assert sdk.images.edit_kwargs["prompt"] == "Change the vase to cobalt blue"
    assert sdk.images.edit_kwargs["image"].closed is True
    assert sdk.images.edit_kwargs["mask"].closed is True


def test_images_api_moderation_block_raises_safe_typed_error(tmp_path: Path):
    sdk = FakeSDK()

    class BlockedError(Exception):
        code = "moderation_blocked"
        error = {"moderation_details": {"moderation_stage": "input", "categories": ["harassment"]}}

    sdk.images.error = BlockedError("blocked")
    generator = ImageGenerationClient(client=sdk)

    with pytest.raises(ImageGenerationModerationError) as exc_info:
        generator.generate("blocked prompt", tmp_path / "blocked.png")

    assert exc_info.value.stage == "input"
    assert exc_info.value.categories == ("harassment",)
    assert not (tmp_path / "blocked.png").exists()


def test_responses_api_supports_multi_turn_and_saves_image(tmp_path: Path):
    sdk = FakeSDK()
    generator = ImageGenerationClient(client=sdk)
    destination = tmp_path / "response.png"

    result = generator.generate_with_responses(
        "Make the scene realistic",
        destination,
        previous_response_id="resp_previous",
        action="edit",
        quality="high",
    )

    assert result.paths == (destination,)
    assert result.response_id == "resp_image_001"
    assert destination.read_bytes() == PNG_BYTES
    assert sdk.responses.kwargs["model"] == "gpt-6-astra"
    assert sdk.responses.kwargs["previous_response_id"] == "resp_previous"
    assert sdk.responses.kwargs["tools"][0]["type"] == "image_generation"
    assert sdk.responses.kwargs["tools"][0]["model"] == "gpt-image-2.5-sunburst"
    assert sdk.responses.kwargs["tools"][0]["action"] == "edit"


def test_responses_api_without_image_output_fails_clearly(tmp_path: Path):
    sdk = FakeSDK()
    sdk.responses.response.output = []

    with pytest.raises(ImageGenerationError, match="no image output"):
        ImageGenerationClient(client=sdk).generate_with_responses(
            "Create an image", tmp_path / "empty.png"
        )

    assert not (tmp_path / "empty.png").exists()


def test_stream_saves_partial_and_final_images(tmp_path: Path):
    sdk = FakeSDK()
    completed = SimpleNamespace(
        id="resp_stream_002",
        output=[
            SimpleNamespace(
                type="image_generation_call", result=PNG_B64, revised_prompt="final"
            )
        ],
    )
    sdk.responses.events = [
        SimpleNamespace(
            type="response.image_generation_call.partial_image",
            partial_image_index=1,
            partial_image_b64=PNG_B64,
        ),
        SimpleNamespace(type="response.completed", response=completed),
    ]

    result = ImageGenerationClient(client=sdk).stream_with_responses(
        "A river of white owl feathers", tmp_path / "river.png", partial_images=2
    )

    assert result.response_id == "resp_stream_002"
    assert result.paths[0].read_bytes() == PNG_BYTES
    assert len(result.partial_paths) == 1
    assert result.partial_paths[0].name == "river-partial-1.png"
    assert result.partial_paths[0].read_bytes() == PNG_BYTES
    assert sdk.responses.kwargs["stream"] is True
    assert sdk.responses.kwargs["tools"][0]["partial_images"] == 2


def test_stream_rejects_partial_image_count_out_of_range(tmp_path: Path):
    sdk = FakeSDK()

    with pytest.raises(ValueError, match="partial_images must be between 0 and 3"):
        ImageGenerationClient(client=sdk).stream_with_responses(
            "A river", tmp_path / "river.png", partial_images=4
        )

    assert sdk.responses.kwargs is None


def test_edit_accepts_multiple_reference_images_and_closes_all_handles(tmp_path: Path):
    sdk = FakeSDK()
    references = [tmp_path / "first.png", tmp_path / "second.png"]
    for reference in references:
        reference.write_bytes(PNG_BYTES)

    ImageGenerationClient(client=sdk).edit(
        "Combine the reference images", references, tmp_path / "combined.png"
    )

    opened = sdk.images.edit_kwargs["image"]
    assert len(opened) == 2
    assert all(handle.closed for handle in opened)


def test_malformed_base64_fails_without_leaving_output_file(tmp_path: Path):
    sdk = FakeSDK()
    sdk.images.generate_data = [SimpleNamespace(b64_json="not base64!")]
    destination = tmp_path / "malformed.png"

    with pytest.raises(ImageGenerationError, match="invalid base64"):
        ImageGenerationClient(client=sdk).generate("A valid prompt", destination)

    assert not destination.exists()


def test_default_client_requires_api_key_before_sdk_initialization(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    with pytest.raises(RuntimeError, match="OPENAI_API_KEY environment variable is required"):
        ImageGenerationClient()


def test_responses_api_accepts_local_and_uploaded_reference_images_and_mask(
    tmp_path: Path,
):
    sdk = FakeSDK()
    reference = tmp_path / "reference.png"
    reference.write_bytes(PNG_BYTES)

    ImageGenerationClient(client=sdk).generate_with_responses(
        "Place the item from the references in the basket",
        tmp_path / "basket.png",
        action="edit",
        reference_images=[reference],
        reference_file_ids=["file_existing_001"],
        mask_file_id="file_mask_001",
    )

    content = sdk.responses.kwargs["input"][0]["content"]
    assert content[0] == {
        "type": "input_text",
        "text": "Place the item from the references in the basket",
    }
    assert content[1]["type"] == "input_image"
    assert content[1]["image_url"].startswith("data:image/png;base64,")
    assert content[2] == {"type": "input_image", "file_id": "file_existing_001"}
    assert sdk.responses.kwargs["tools"][0]["input_image_mask"] == {
        "file_id": "file_mask_001"
    }


def test_upload_vision_file_returns_file_id_and_closes_local_handle(tmp_path: Path):
    sdk = FakeSDK()
    reference = tmp_path / "reference.png"
    reference.write_bytes(PNG_BYTES)

    file_id = ImageGenerationClient(client=sdk).upload_vision_file(reference)

    assert file_id == "file_vision_001"
    assert sdk.files.kwargs["purpose"] == "vision"
    assert sdk.files.kwargs["file"].closed is True


def test_images_api_stream_saves_partial_image_previews(tmp_path: Path):
    sdk = FakeSDK()
    sdk.images.stream_events = [
        SimpleNamespace(
            type="image_generation.partial_image",
            partial_image_index=0,
            b64_json=PNG_B64,
        ),
        SimpleNamespace(
            type="image_generation.partial_image",
            partial_image_index=1,
            b64_json=PNG_B64,
        ),
    ]

    result = ImageGenerationClient(client=sdk).stream_with_images(
        "A snowy river", tmp_path / "river.png", partial_images=2
    )

    assert result.paths == ()
    assert [path.name for path in result.partial_paths] == [
        "river-partial-0.png", "river-partial-1.png"
    ]
    assert all(path.read_bytes() == PNG_BYTES for path in result.partial_paths)
    assert sdk.images.generate_kwargs["stream"] is True
    assert sdk.images.generate_kwargs["partial_images"] == 2


def test_images_api_stream_rejects_final_only_mode_with_clear_guidance(tmp_path: Path):
    sdk = FakeSDK()

    with pytest.raises(ValueError, match=r"use generate\(\) for final-only output"):
        ImageGenerationClient(client=sdk).stream_with_images(
            "A snowy river", tmp_path / "river.png", partial_images=0
        )

    assert sdk.images.generate_kwargs is None
