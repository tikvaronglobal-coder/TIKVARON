"""Reusable OpenAI image-generation service for TIKVARON applications."""
from __future__ import annotations

import base64
import binascii
import contextlib
import mimetypes
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

DEFAULT_IMAGE_MODEL = "gpt-image-2.5-sunburst"
DEFAULT_RESPONSES_MODEL = "gpt-6-astra"
_ALLOWED_ACTIONS = {"auto", "generate", "edit"}


class ImageGenerationError(RuntimeError):
    """Raised when an image operation cannot produce a valid image file."""


class ImageGenerationModerationError(ImageGenerationError):
    """A moderation block, with the non-sensitive details exposed to callers."""

    def __init__(
        self,
        message: str = "The image request was blocked by a safety check.",
        *,
        stage: str | None = None,
        categories: Sequence[str] = (),
    ) -> None:
        super().__init__(message)
        self.stage = stage
        self.categories = tuple(categories)


@dataclass(frozen=True)
class ImageResult:
    """Files and metadata returned by a completed image operation."""

    paths: tuple[Path, ...]
    model: str
    response_id: str | None = None
    partial_paths: tuple[Path, ...] = ()
    revised_prompts: tuple[str, ...] = ()


class ImageGenerationClient:
    """Generate and edit images through OpenAI Images and Responses APIs.

    An SDK client may be injected for tests. In normal use the OpenAI SDK
    reads ``OPENAI_API_KEY`` from the process environment.
    """

    def __init__(
        self,
        client: Any | None = None,
        image_model: str | None = None,
        responses_model: str | None = None,
    ) -> None:
        if client is None:
            if not os.getenv("OPENAI_API_KEY"):
                raise RuntimeError("OPENAI_API_KEY environment variable is required")
            try:
                from openai import OpenAI
            except ImportError as exc:  # pragma: no cover - dependency packaging guard
                raise RuntimeError(
                    "Install the OpenAI SDK with `pip install tikvaron-image-generation`."
                ) from exc
            client = OpenAI()
        self.client = client
        self.image_model = (
            image_model or os.getenv("TIKVARON_IMAGE_MODEL") or DEFAULT_IMAGE_MODEL
        ).strip()
        self.responses_model = (
            responses_model
            or os.getenv("TIKVARON_IMAGE_RESPONSES_MODEL")
            or DEFAULT_RESPONSES_MODEL
        ).strip()
        if not self.image_model or not self.responses_model:
            raise ValueError("Image and Responses model names must not be empty")

    def generate(
        self,
        prompt: str,
        output_path: str | Path,
        *,
        quality: str = "auto",
        size: str = "auto",
        n: int = 1,
    ) -> ImageResult:
        """Create one or more images using the Images API."""
        _validate_prompt(prompt)
        _validate_count(n)
        destination = Path(output_path)
        try:
            response = self.client.images.generate(
                model=self.image_model,
                prompt=prompt,
                quality=quality,
                size=size,
                n=n,
                output_format="png",
            )
        except Exception as exc:
            _raise_if_moderation_blocked(exc)
            raise
        data = getattr(response, "data", None) or []
        if len(data) < n:
            raise ImageGenerationError(
                f"OpenAI returned {len(data)} image(s); {n} were requested."
            )
        saved = _save_image_items(data[:n], destination)
        revised = tuple(
            str(item.revised_prompt)
            for item in data[:n]
            if getattr(item, "revised_prompt", None)
        )
        return ImageResult(paths=saved, model=self.image_model, revised_prompts=revised)

    def edit(
        self,
        prompt: str,
        image: str | Path | Sequence[str | Path],
        output_path: str | Path,
        *,
        mask: str | Path | None = None,
        quality: str = "auto",
        size: str = "auto",
        n: int = 1,
    ) -> ImageResult:
        """Edit one or more reference images, optionally using an edit mask."""
        _validate_prompt(prompt)
        _validate_count(n)
        references = [image] if isinstance(image, (str, Path)) else list(image)
        if not references:
            raise ValueError("at least one reference image is required")
        for reference in references:
            if not Path(reference).is_file():
                raise FileNotFoundError(f"reference image not found: {reference}")
        if mask is not None and not Path(mask).is_file():
            raise FileNotFoundError(f"mask image not found: {mask}")

        with contextlib.ExitStack() as stack:
            opened_images = [stack.enter_context(open(path, "rb")) for path in references]
            opened_mask = stack.enter_context(open(mask, "rb")) if mask is not None else None
            kwargs: dict[str, Any] = {
                "model": self.image_model,
                "prompt": prompt,
                "image": opened_images[0] if len(opened_images) == 1 else opened_images,
                "quality": quality,
                "size": size,
                "n": n,
                "output_format": "png",
            }
            if opened_mask is not None:
                kwargs["mask"] = opened_mask
            try:
                response = self.client.images.edit(**kwargs)
            except Exception as exc:
                _raise_if_moderation_blocked(exc)
                raise

        data = getattr(response, "data", None) or []
        if len(data) < n:
            raise ImageGenerationError(
                f"OpenAI returned {len(data)} edited image(s); {n} were requested."
            )
        saved = _save_image_items(data[:n], Path(output_path))
        revised = tuple(
            str(item.revised_prompt)
            for item in data[:n]
            if getattr(item, "revised_prompt", None)
        )
        return ImageResult(paths=saved, model=self.image_model, revised_prompts=revised)

    def stream_with_images(
        self,
        prompt: str,
        output_path: str | Path,
        *,
        partial_images: int = 2,
        quality: str = "auto",
        size: str = "auto",
    ) -> ImageResult:
        """Save the progressive preview events returned by Images API streaming."""
        _validate_prompt(prompt)
        _validate_partial_images(partial_images)
        if partial_images == 0:
            raise ValueError(
                "Images API preview streaming requires 1 to 3 partial images; "
                "use generate() for final-only output"
            )
        destination = Path(output_path)
        try:
            events = self.client.images.generate(
                model=self.image_model,
                prompt=prompt,
                quality=quality,
                size=size,
                stream=True,
                partial_images=partial_images,
            )
            partial_paths = []
            for event in events:
                if getattr(event, "type", None) != "image_generation.partial_image":
                    continue
                encoded = getattr(event, "b64_json", None)
                if not encoded:
                    continue
                index = int(getattr(event, "partial_image_index", len(partial_paths)))
                partial_path = _partial_path(destination, index)
                _save_base64(encoded, partial_path)
                partial_paths.append(partial_path)
        except Exception as exc:
            _raise_if_moderation_blocked(exc)
            raise
        return ImageResult(
            paths=(),
            model=self.image_model,
            partial_paths=tuple(partial_paths),
        )

    def upload_vision_file(self, file_path: str | Path) -> str:
        """Upload a reference image for Responses API use and return its file ID.

        The upload is retained in the OpenAI project until it is deleted separately
        through the Files API; this helper intentionally does not delete it.
        """
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"image file not found: {path}")
        with open(path, "rb") as image_file:
            uploaded = self.client.files.create(file=image_file, purpose="vision")
        file_id = getattr(uploaded, "id", None)
        if not file_id:
            raise ImageGenerationError("Files API upload did not return a file ID")
        return str(file_id)

    def generate_with_responses(
        self,
        prompt: str,
        output_path: str | Path,
        *,
        previous_response_id: str | None = None,
        action: str = "auto",
        quality: str = "auto",
        size: str = "auto",
        reference_images: Sequence[str | Path] = (),
        reference_file_ids: Sequence[str] = (),
        mask_file_id: str | None = None,
    ) -> ImageResult:
        """Generate/edit with optional local or previously uploaded reference images."""
        _validate_prompt(prompt)
        _validate_action(action)
        if mask_file_id and not mask_file_id.strip():
            raise ValueError("mask_file_id must be a non-empty string")
        if mask_file_id and action == "generate":
            raise ValueError("mask_file_id cannot be used when action is generate")
        local_references = (
            [reference_images]
            if isinstance(reference_images, (str, Path))
            else list(reference_images)
        )
        file_ids = (
            [reference_file_ids]
            if isinstance(reference_file_ids, str)
            else list(reference_file_ids)
        )
        content: list[dict[str, Any]] = [{"type": "input_text", "text": prompt}]
        for image_path in local_references:
            path = Path(image_path)
            if not path.is_file():
                raise FileNotFoundError(f"reference image not found: {path}")
            mime_type, _ = mimetypes.guess_type(path.name)
            if mime_type not in {"image/png", "image/jpeg", "image/webp", "image/gif"}:
                raise ValueError(f"unsupported reference image type: {path.suffix or 'unknown'}")
            encoded = base64.b64encode(path.read_bytes()).decode("ascii")
            content.append(
                {
                    "type": "input_image",
                    "image_url": f"data:{mime_type};base64,{encoded}",
                }
            )
        for file_id in file_ids:
            if not isinstance(file_id, str) or not file_id.strip():
                raise ValueError("reference file IDs must be non-empty strings")
            content.append({"type": "input_image", "file_id": file_id.strip()})
        response_input: str | list[dict[str, Any]] = prompt
        if local_references or file_ids:
            response_input = [{"role": "user", "content": content}]
        image_tool = {
            "type": "image_generation",
            "model": self.image_model,
            "action": action,
            "quality": quality,
            "size": size,
        }
        if mask_file_id:
            image_tool["input_image_mask"] = {"file_id": mask_file_id}
        kwargs: dict[str, Any] = {
            "model": self.responses_model,
            "input": response_input,
            "tools": [image_tool],
        }
        if previous_response_id:
            kwargs["previous_response_id"] = previous_response_id
        try:
            response = self.client.responses.create(**kwargs)
        except Exception as exc:
            _raise_if_moderation_blocked(exc)
            raise
        calls = _image_calls(getattr(response, "output", None))
        if not calls:
            raise ImageGenerationError("Responses API returned no image output")
        saved = _save_image_items(calls[:1], Path(output_path), result_field=True)
        revised = tuple(
            str(item.revised_prompt)
            for item in calls[:1]
            if getattr(item, "revised_prompt", None)
        )
        return ImageResult(
            paths=saved,
            model=self.responses_model,
            response_id=getattr(response, "id", None),
            revised_prompts=revised,
        )

    def stream_with_responses(
        self,
        prompt: str,
        output_path: str | Path,
        *,
        partial_images: int = 2,
        previous_response_id: str | None = None,
        action: str = "auto",
        quality: str = "auto",
        size: str = "auto",
    ) -> ImageResult:
        """Stream partial previews and persist the completed Responses image."""
        _validate_prompt(prompt)
        _validate_action(action)
        _validate_partial_images(partial_images)
        destination = Path(output_path)
        tool = {
            "type": "image_generation",
            "model": self.image_model,
            "action": action,
            "quality": quality,
            "size": size,
            "partial_images": partial_images,
        }
        kwargs: dict[str, Any] = {
            "model": self.responses_model,
            "input": prompt,
            "tools": [tool],
            "stream": True,
        }
        if previous_response_id:
            kwargs["previous_response_id"] = previous_response_id
        try:
            events: Iterable[Any] = self.client.responses.create(**kwargs)
            completed_response = None
            partial_paths: list[Path] = []
            for event in events:
                event_type = getattr(event, "type", None)
                if event_type == "response.image_generation_call.partial_image":
                    index = getattr(event, "partial_image_index", len(partial_paths))
                    image_b64 = getattr(event, "partial_image_b64", None)
                    if image_b64:
                        partial_destination = _partial_path(destination, int(index))
                        _save_base64(image_b64, partial_destination)
                        partial_paths.append(partial_destination)
                elif event_type == "response.completed":
                    completed_response = getattr(event, "response", None)
        except Exception as exc:
            _raise_if_moderation_blocked(exc)
            raise

        if completed_response is None:
            raise ImageGenerationError("Responses stream ended without a completed response")
        calls = _image_calls(getattr(completed_response, "output", None))
        if not calls:
            raise ImageGenerationError("Responses stream completed with no image output")
        saved = _save_image_items(calls[:1], destination, result_field=True)
        revised = tuple(
            str(item.revised_prompt)
            for item in calls[:1]
            if getattr(item, "revised_prompt", None)
        )
        return ImageResult(
            paths=saved,
            model=self.responses_model,
            response_id=getattr(completed_response, "id", None),
            partial_paths=tuple(partial_paths),
            revised_prompts=revised,
        )


def _validate_prompt(prompt: str) -> None:
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("prompt must not be empty")


def _validate_count(n: int) -> None:
    if not isinstance(n, int) or not 1 <= n <= 10:
        raise ValueError("n must be between 1 and 10")


def _validate_action(action: str) -> None:
    if action not in _ALLOWED_ACTIONS:
        raise ValueError("action must be one of: auto, generate, edit")


def _validate_partial_images(partial_images: int) -> None:
    if not isinstance(partial_images, int) or not 0 <= partial_images <= 3:
        raise ValueError("partial_images must be between 0 and 3")


def _image_calls(outputs: Iterable[Any] | None) -> list[Any]:
    return [
        item
        for item in (outputs or [])
        if getattr(item, "type", None) == "image_generation_call"
        and getattr(item, "result", None)
    ]


def _save_image_items(
    items: Sequence[Any], destination: Path, *, result_field: bool = False
) -> tuple[Path, ...]:
    paths: list[Path] = []
    for index, item in enumerate(items, start=1):
        encoded = getattr(item, "result", None) if result_field else getattr(item, "b64_json", None)
        if not encoded:
            raise ImageGenerationError("OpenAI image output did not include base64 image data")
        path = destination if index == 1 else _numbered_path(destination, index)
        _save_base64(encoded, path)
        paths.append(path)
    return tuple(paths)


def _save_base64(encoded: str, destination: Path) -> None:
    try:
        image_bytes = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError, TypeError) as exc:
        raise ImageGenerationError("OpenAI returned invalid base64 image data") from exc
    destination.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    descriptor = os.open(destination, flags, 0o600)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as image_file:
            descriptor = -1
            image_file.write(image_bytes)
    finally:
        if descriptor >= 0:
            os.close(descriptor)


def _numbered_path(path: Path, index: int) -> Path:
    return path.with_name(f"{path.stem}-{index}{path.suffix or '.png'}")


def _partial_path(path: Path, index: int) -> Path:
    return path.with_name(f"{path.stem}-partial-{index}{path.suffix or '.png'}")


def _as_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if value is None:
        return {}
    try:
        return dict(value)
    except (TypeError, ValueError):
        return {}


def _raise_if_moderation_blocked(exc: Exception) -> None:
    error_payload = getattr(exc, "error", None)
    if not error_payload:
        error_payload = getattr(exc, "body", None)
    payload = _as_mapping(error_payload)
    if isinstance(payload.get("error"), dict):
        payload = payload["error"]
    code = getattr(exc, "code", None) or payload.get("code")
    if code != "moderation_blocked":
        return
    details = _as_mapping(payload.get("moderation_details"))
    categories = details.get("categories") or []
    raise ImageGenerationModerationError(
        (
            "The image request was blocked by a safety check. Revise the prompt or "
            "input images and try again."
        ),
        stage=details.get("moderation_stage"),
        categories=tuple(str(category) for category in categories),
    ) from exc
